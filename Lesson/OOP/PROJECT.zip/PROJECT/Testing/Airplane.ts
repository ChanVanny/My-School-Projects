export class Airplane {
    constructor(private registrationNumber: string){}
}