export class Gate {
    constructor(private gateNumber: string){}
}