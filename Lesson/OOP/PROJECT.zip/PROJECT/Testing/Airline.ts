export class Airline {
    constructor(private name: string){}
}