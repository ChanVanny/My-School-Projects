export class Address{
    city:string;
    country:string;

    constructor(city:string, street:string){
        this.city = city;
        this.country = street;
    }
}