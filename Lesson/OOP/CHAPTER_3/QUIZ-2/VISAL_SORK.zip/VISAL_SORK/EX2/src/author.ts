export class Author {
    public name : string;

    constructor(name : string){
        this.name = name;
    }
}