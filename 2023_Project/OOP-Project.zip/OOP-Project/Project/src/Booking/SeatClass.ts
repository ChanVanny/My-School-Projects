export enum SeatClass{
    ECONOMY_CLASSIC,
    ECONOMY_FLEX,
    BUSINESS_CLASS
}