export class Seat {
  constructor(private seatNumber: string) {}
}
