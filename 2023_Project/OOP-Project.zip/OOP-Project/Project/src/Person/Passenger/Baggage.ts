export class Baggage{
    constructor(private baggeageId : string){}
}