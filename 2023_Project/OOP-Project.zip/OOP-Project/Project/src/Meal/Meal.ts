export enum MealType{
    VEGETARIAN,
    VEGAN,
    DAIRY_FREE,
    HALAL,
    KOSHER,
    FORTH
}