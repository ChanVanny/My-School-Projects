export class Total {
    private orderItems: [];
    private totalPrice: number;

    constructor() {
        this.orderItems = [];
        this.totalPrice = 0;
    }
}



