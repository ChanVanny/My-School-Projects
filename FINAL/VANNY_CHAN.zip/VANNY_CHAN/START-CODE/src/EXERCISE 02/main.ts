
import { Restaurant } from "./src/Restaurant";
import { Menu } from "./src/Product";
import { Total } from "./src/Total";
import { Customer } from "./src/Customer";

// Create restaurant
let restaurant:Restaurant = new Restaurant("Vanny");

// create Products
// let pizza:Menu = new Menu("Pizza","Pizza is so yummy", 200);