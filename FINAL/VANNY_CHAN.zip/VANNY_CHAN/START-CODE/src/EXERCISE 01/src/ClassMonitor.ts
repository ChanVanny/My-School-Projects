
import { Student } from "./Student";

export class ClassMonitor extends Student{
    constructor(name:string, age:number, phone:number){
        super(phone,name,age)
        
    }
}